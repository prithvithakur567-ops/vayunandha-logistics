VAYUNANDHA LOGISTICS — starter website

Files:
- index.html: responsive website homepage
- assets/vayunandha-driver-flyer.jpeg: user-provided promotional flyer
- assets/vayunandha-services.jpeg: user-provided services graphic

Preview:
Open index.html in a browser.

Quote form:
The form opens the visitor's default email app using a mailto link. It does not store or submit data to a server. To receive enquiries reliably from all devices, connect a form service or backend before relying on it commercially.

Before publishing:
- Confirm the company services, locations, insurance and claims.
- Phone: 07512631336
Email: Vayunandhalogistics@gmail.com
- Check image usage and readability on mobile.
- Add a privacy notice if collecting personal information through a hosted form.
